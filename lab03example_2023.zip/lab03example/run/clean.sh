#!/bin/bash
rm -rf cov_work
rm -f *.log
rm -f xrun.key
rm -rf INCA_libs*
rm -rf xcelium.d
rm -f *.history
rm -f *.rpt
rm -rf waves.shm
rm -rf .simvision*
