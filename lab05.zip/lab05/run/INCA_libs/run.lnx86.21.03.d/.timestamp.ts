1697368421 /home/student/kbajur/VDIC/common/vdic_dut_2023.svp
1700592201 /home/student/kbajur/VDIC/lab05/tb/mult_bfm.sv
1700592201 /home/student/kbajur/VDIC/lab05/tb/mult_pkg.sv
1700592202 /home/student/kbajur/VDIC/lab05/tb/top.sv
